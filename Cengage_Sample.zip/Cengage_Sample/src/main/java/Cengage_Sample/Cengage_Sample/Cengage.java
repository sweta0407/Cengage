package Cengage_Sample.Cengage_Sample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Cengage {

	final static String URL = "http://demoqa.com/registration/";
	final static String First_Name = "Sweta";
	final static String Last_Name = "Barad";
	final static String Marital_Status = "married";
	final static String Hobby = "dance";
	final static String Country = "United States";
	final static String DOB_Date = "4";
	final static String DOB_Month = "1";
	final static String DOB_Year = "1989";
	final static String Phone_Number = "4016540648";
	final static String Description = "My Name is Sweta";
	final static String User_Name = "swetabarad";
	final static String Email_Domain = "@cengage.com";
	final static String File_Path = System.getProperty("user.dir") + "\\src\\main\\java\\Cengage_Sample\\Cengage_Sample\\upload.gif";
	final static String IE_Driver_Path = System.getProperty("user.dir") + "\\src\\main\\java\\Cengage_Sample\\Cengage_Sample\\IEDriverServer.exe";
    final static String Current_Timestamp = new SimpleDateFormat("yyyyMMdd_HHmmssSSSZ").format(Calendar.getInstance().getTime());
	final static String Weak_Password = "Krishna12$";
	final static String Strong_Password = "Jaimatadi@1001";
    final static String Expected_Weak_Message = "Weak";
    final static String Expected_Strong_Message = "Strong";
    final static String Expected_Mismatch_Message = "Mismatch";
    final static String expected_Success_Message = "Thank you for your registration";    
    WebDriver driver ;
    
    @Before 
    public void beforeTest(){
		//Locating IE Driver
    	System.setProperty("webdriver.ie.driver",IE_Driver_Path);
        DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();
        ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
    	driver = new InternetExplorerDriver(ieCapabilities);
        //Launching IE Driver and Navigating to URL 
		driver.manage().window().maximize();
		driver.get(URL);
    }
    
    @After
    public void killDriver()
    {	
    	
    	driver.quit();
    	System.gc();
    }

    @Test
    public void junitTest(){	
        WebDriverWait wait = new WebDriverWait(driver,10);
        //Waiting for the page to load
       wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("first_name")));
		//Locating and Entering value in First Name 
		WebElement firstName = driver.findElement(By.name("first_name"));
		firstName.sendKeys(First_Name);
		
		//Locating and Entering value in Last Name
		WebElement lastName = driver.findElement(By.name("last_name"));
		lastName.sendKeys(Last_Name);
		
		//Locating and Entering value in Marital Status
		WebElement maritalStatus = driver.findElement(By.cssSelector("input[value='" + Marital_Status + "']"));
		maritalStatus.click();
		
		//Locating and Entering value in Hobby
		WebElement hobby = driver.findElement(By.cssSelector("input[value='" + Hobby + "']"));
		hobby.click();
		
		//Locating and Entering value in Country
		Select country = new Select(driver.findElement(By.id("dropdown_7")));
	    country.selectByVisibleText(Country);
	    
		//Locating and Entering value in Date of Birth
		Select dobMonth = new Select(driver.findElement(By.id("mm_date_8")));
		dobMonth.selectByVisibleText(DOB_Month);
		Select dobDay = new Select(driver.findElement(By.id("dd_date_8")));
		dobDay.selectByVisibleText(DOB_Date);
		Select dobYear = new Select(driver.findElement(By.id("yy_date_8")));
		dobYear.selectByVisibleText(DOB_Year);
		
		//Locating and Entering value in First Name 
		WebElement phoneNum = driver.findElement(By.name("phone_9"));
		phoneNum.sendKeys(Phone_Number);		

		//Locating and Entering value in Last Name 
		WebElement userName = driver.findElement(By.name("username"));
		userName.sendKeys(User_Name + Current_Timestamp);

		//Locating and Entering value in Email
		WebElement email = driver.findElement(By.name("e_mail"));
		email.sendKeys(User_Name + Current_Timestamp + Email_Domain);		
		
		//Locating and Entering value in Profile Picture
		WebElement profilePicture = driver.findElement(By.id("profile_pic_10"));
		profilePicture.sendKeys(File_Path);
		
		//Locating and Entering value in Description
		WebElement aboutYou = driver.findElement(By.name("description"));
		aboutYou.sendKeys(Description);
		
		//Locating and Entering value in Password
		WebElement password = driver.findElement(By.name("password"));
		
		//*************** Validation of weak password starts ********************
		password.sendKeys(Weak_Password);
		WebElement pwdstre = driver.findElement(By.id("piereg_passwordStrength"));
		String actualweakAlertMessage = pwdstre.getText().trim();

		Assert.assertEquals(actualweakAlertMessage,Expected_Weak_Message);
        System.out.println("Weak Password Validation Successful");
		//*************** Validation of weak password Ends ********************
       
      //*************** Validation of Strong password starts ********************
        password.clear();
        password.sendKeys(Strong_Password);
        String actualStrongAlertMessage = pwdstre.getText().trim();
        
        Assert.assertEquals(actualStrongAlertMessage,Expected_Strong_Message);
        System.out.println("Strong Password Validation Successful");
      //*************** Validation of Strong password Ends ********************
        
      //*************** Validation of Mismatch password starts ********************
        password.clear();
        password.sendKeys(Strong_Password);
        WebElement confirmpwd = driver.findElement(By.id("confirm_password_password_2"));
        confirmpwd.sendKeys(Weak_Password);
        String actualMismatchAlertMessage = pwdstre.getText().trim();
        Assert.assertEquals(actualMismatchAlertMessage,Expected_Mismatch_Message);
        System.out.println("Mismatch Password Validation Successful");
      //*************** Validation of Mismatch password Ends ********************
        
        //Entering Strong Password Again
        confirmpwd.clear();
        confirmpwd.sendKeys(Strong_Password);
        
        //Submitting the form
        WebElement submit = driver.findElement(By.name("pie_submit"));
        submit.click();

        //Waiting for the page to load
       wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("piereg_message")));
        
        //*************** Validation of Success Message Starts ********************
        String actualSuccessmessage=driver.findElement(By.className("piereg_message")).getText().trim();
        Assert.assertEquals(actualSuccessmessage,expected_Success_Message);
        System.out.println("Successfully Registered");
      //*************** Validation of Success Message Ends ********************
		}

		
	}

